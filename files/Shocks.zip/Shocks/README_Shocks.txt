Estimated shock series for 
Brinca, Duarte and Faria-e-Castro (2020) 
"Measuring Sectoral Supply and Demand Shocks during COVID-19"
Federal Reserve Bank of St. Louis Working Paper 2020-011

Estimated time series for supply and demand shocks available at the sector level for:
- hours.xlsx
- wages.xlsx

"_L" and "_U" correspond to the lower and upper bound of 95% credible intervals, respectively.
